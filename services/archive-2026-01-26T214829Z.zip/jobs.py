from __future__ import annotations

from dataclasses import dataclass
from random import randint

from sqlalchemy.ext.asyncio import AsyncSession

from db.models import JobRow, JobProgressRow, UserJobSlotRow, WalletRow
from sqlalchemy import select

# Step 3 will flesh this out.
# This module exists now so imports are stable and you can build on it.


@dataclass(frozen=True)
class WorkResult:
    job_key: str
    job_name: str
    outcome: str  # "normal" | "jackpot" | "fail"
    silver_delta: int
    job_xp_gain: int


async def get_equipped_job(session: AsyncSession, *, guild_id: int, user_id: int, slot_index: int = 0) -> JobRow | None:
    res = await session.execute(
        select(UserJobSlotRow).where(
            UserJobSlotRow.guild_id == guild_id,
            UserJobSlotRow.user_id == user_id,
            UserJobSlotRow.slot_index == slot_index,
        )
    )
    slot = res.scalar_one_or_none()
    if slot is None:
        return None

    res = await session.execute(select(JobRow).where(JobRow.id == slot.job_id))
    return res.scalar_one_or_none()


async def apply_silver(session: AsyncSession, *, guild_id: int, user_id: int, delta: int) -> None:
    res = await session.execute(
        select(WalletRow).where(WalletRow.guild_id == guild_id, WalletRow.user_id == user_id).with_for_update()
    )
    w = res.scalar_one()
    w.silver += int(delta)
    if delta > 0:
        w.silver_earned += int(delta)
    elif delta < 0:
        w.silver_spent += int(-delta)


async def ensure_job_progress(session: AsyncSession, *, guild_id: int, user_id: int, job_id: int) -> JobProgressRow:
    res = await session.execute(
        select(JobProgressRow)
        .where(JobProgressRow.guild_id == guild_id, JobProgressRow.user_id == user_id, JobProgressRow.job_id == job_id)
        .with_for_update()
    )
    row = res.scalar_one_or_none()
    if row is None:
        row = JobProgressRow(guild_id=guild_id, user_id=user_id, job_id=job_id, job_xp=0, job_level=1, job_title="Recruit")
        session.add(row)
        await session.flush()
    return row


def roll_90_5_5(*, jackpot_bp: int = 500, fail_bp: int = 500) -> str:
    # basis points: 10000 = 100.00%
    r = randint(1, 10000)
    if r <= fail_bp:
        return "fail"
    if r <= fail_bp + jackpot_bp:
        return "jackpot"
    return "normal"
