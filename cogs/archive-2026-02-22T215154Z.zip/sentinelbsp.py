# cogs/sentinel_bootstrap.py
from __future__ import annotations

from typing import Optional

from discord.ext import commands
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine

from services.db import sessions


class SentinelBootstrapCog(commands.Cog):
    """
    One-time bootstrap: creates Sentinel tables if they don't exist.
    Safe to remove after first successful startup.
    """

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._sessionmaker = sessions()
        self._ran = False

    async def _exec(self, sql: str) -> None:
        # sessions() returns sessionmaker; we can reach the engine via the session bind
        async with self._sessionmaker() as session:
            bind = session.get_bind()
            if bind is None:
                raise RuntimeError("SQLAlchemy session has no bind/engine.")
            await session.execute(text(sql))

    async def _ensure_tables(self) -> None:
        # NOTE: This is MySQL-friendly DDL (aiomysql). Works with InnoDB defaults.
        # Uses BIGINT for snowflakes, JSON for payloads, DATETIME(6) for precision.
        # If your DB is strict about JSON, ensure MySQL 5.7+ (or MariaDB variant with JSON support).

        await self._exec(
            """
            CREATE TABLE IF NOT EXISTS sentinel_events (
                id INT NOT NULL AUTO_INCREMENT,
                guild_id BIGINT NOT NULL,
                case_id VARCHAR(40) NOT NULL,
                event_type VARCHAR(48) NOT NULL,
                severity VARCHAR(10) NOT NULL DEFAULT 'INFO',
                actor_user_id BIGINT NULL,
                target_user_id BIGINT NULL,
                channel_id BIGINT NULL,
                message_id BIGINT NULL,
                summary VARCHAR(512) NOT NULL DEFAULT '',
                payload_json JSON NOT NULL,
                created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                PRIMARY KEY (id),
                UNIQUE KEY uq_sentinel_events_guild_case (guild_id, case_id),
                KEY ix_sentinel_events_guild_created (guild_id, created_at),
                KEY ix_sentinel_events_guild_type_created (guild_id, event_type, created_at),
                KEY ix_sentinel_events_guild_actor_created (guild_id, actor_user_id, created_at),
                KEY ix_sentinel_events_guild_target_created (guild_id, target_user_id, created_at),
                KEY ix_sentinel_events_guild_channel_created (guild_id, channel_id, created_at),
                KEY ix_sentinel_events_guild_message (guild_id, channel_id, message_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            """
        )

        await self._exec(
            """
            CREATE TABLE IF NOT EXISTS sentinel_bot_trust (
                id INT NOT NULL AUTO_INCREMENT,
                guild_id BIGINT NOT NULL,
                bot_user_id BIGINT NOT NULL,
                first_seen_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                last_seen_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                trust_score INT NOT NULL DEFAULT 0,
                is_whitelisted TINYINT(1) NOT NULL DEFAULT 0,
                app_commands_seen INT NOT NULL DEFAULT 0,
                interactions_seen INT NOT NULL DEFAULT 0,
                note VARCHAR(200) NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_sentinel_bot_trust_guild_bot (guild_id, bot_user_id),
                KEY ix_sentinel_bot_trust_guild_score (guild_id, trust_score),
                KEY ix_sentinel_bot_trust_guild_seen (guild_id, last_seen_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            """
        )

    @commands.Cog.listener()
    async def on_ready(self):
        if self._ran:
            return
        self._ran = True

        try:
            await self._ensure_tables()
            # Minimal console message so you know it worked. Remove if you want.
            print("[SentinelBootstrap] ensured tables: sentinel_events, sentinel_bot_trust")
        except Exception as e:
            print(f"[SentinelBootstrap] FAILED to ensure tables: {type(e).__name__}: {e}")


async def setup(bot: commands.Bot):
    await bot.add_cog(SentinelBootstrapCog(bot))